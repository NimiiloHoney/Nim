<p align="center">
    <img src="https://github.com/user-attachments/assets/1952f21e-2152-4097-b8c2-9d06bed8aa8c" alt="logo" width="350"/>
</p>

<h3 align="center">A Simple WhatsApp Bot</h3>

<p align="center">
    <strong>FXOP-MD</strong> is a WhatsApp bot made to automate tasks on WhatsApp.
</p>

<p align="center">
    <a href='https://rocky-fjord-18084-7fa90f18d8d2.herokuapp.com/code' target="_blank">
        <img alt='SESSION' src='https://img.shields.io/badge/Get%20Session%20ID-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=blue'/>
    </a>
     <a href="https://whatsapp.com/channel/0029VambPbJ2f3ERs37HvM2J">
        <img alt="WhatsApp" src="https://img.shields.io/badge/-Whatsapp%20Channel-white?style=for-the-badge&logo=whatsapp&logoColor=blue"/>
    </a>
</p>

---

<h2 align="center">Deployments Platforms</h2>

<p align="center">
   <a href="https://www.heroku.com/deploy?template=https://github.com/FXastro/fxop-md">
        <img alt="Heroku" src="https://img.shields.io/badge/-Heroku-430098?style=for-the-badge&logo=heroku&logoColor=white"/>
    </a>
    <a href="https://app.koyeb.com/services/deploy?type=docker&image=docker.io/fxastro/fxop-md&name=fxop-md-demo&env[SESSION_ID]=Session~&env[BOT_INFO]=ᴀsᴛʀᴏ;ғxᴏᴘ-ᴍᴅ&env[SUDO]=2348039607375&env[ANTILINK]=true&env[PORT]=8000&service_type=worker">
    <img alt="Koyeb" src="https://img.shields.io/badge/-Koyeb-1DA1F2?style=for-the-badge&logo=koyeb&logoColor=white"/>
</a>
    <a href="https://whatsapp.com/channel/0029VambPbJ2f3ERs37HvM2J">
        <img alt="Render" src="https://img.shields.io/badge/-Render-003d2b?style=for-the-badge&logo=render&logoColor=white"/>
    </a>
    <a href="https://whatsapp.com/channel/0029VambPbJ2f3ERs37HvM2J">
        <img alt="Railway" src="https://img.shields.io/badge/-Railway-0B0D0E?style=for-the-badge&logo=railway&logoColor=white"/>
    </a>
    <a href="https://whatsapp.com/channel/0029VambPbJ2f3ERs37HvM2J">
        <img alt="Termux" src="https://img.shields.io/badge/-Termux-2CA5E0?style=for-the-badge&logo=shell&logoColor=white"/>
    </a>
    <a href="https://whatsapp.com/channel/0029VambPbJ2f3ERs37HvM2J">
        <img alt="Panel" src="https://img.shields.io/badge/-Panel-FF7139?style=for-the-badge&logo=pterodactyl&logoColor=white"/>
    </a>
</p>

## Warning

This project is **NOT open source** and is **NOT for sale**. Any unauthorized distribution, copying, or use of this project’s code, assets, or any related content is strictly prohibited I keep my oath I do not have access and I will not steal your personal infomation.

If you come across any unauthorized or cheap copy of this project, please report it immediately to **xstrofx010@gmail.com**.

All rights are reserved, and we take any violation seriously, including pursuing legal action to protect our work.

Use this bot at your own risk, WhatsApp will ban you if you use it for spamming.

Thank you for choosing fx-md
